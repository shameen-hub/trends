// var worldwidetrends=new Array("Flash","&nbsp;&nbsp;&nbsp;John","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7.8","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;93%","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;America","Arrow","Elvish" ,"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7.5","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;90%","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Germany","Wonder","Alex","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7.2","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;87%","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Italy","Horrors","kevin","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;6.5","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;75%","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Turkey","Roger","Alice","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5.5","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;59%","&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Bangladesh");
// var World_wide= document.querySelector('#Global Trends');
// document.write("<h1> Shows&nbsp;&nbsp;&nbsp;Directors&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;IMDB&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Audience&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Country&nbsp;&nbsp;&nbsp;&nbsp;&nbsp </h1>" +"<br/>");
// if(World_wide)
// {
//     for(let i=0;i<worldwidetrends.length;i=i+5)
//     {
//         document.write(worldwidetrends[i]+"&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+worldwidetrends[i+1]  +"&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+     worldwidetrends[i+2]+"&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp"+  worldwidetrends[i+3] +"&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp"+  worldwidetrends[i+4]+ "<br/>");
//     }
// }

const movies = new Array("The Shawshank Redemption 1994",
    "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.",
    "Director : Frank Darabont",
    "imdb rating : 9.4",
    "The Godfather (1972)",
    "An organized crime dynasty's aging patriarch transfers control of his clandestine empire to his reluctant son.",
    "Director: Francis Ford Coppola",
    "imdb rating : 9.2",



);
const moviesbtn = document.querySelector(".movies-btn");
const tvbtn = document.querySelector(".tv-btn");
const display_container = document.querySelector(".display-box");
display_container.style.background = "#ffffff";
moviesbtn.addEventListener('click', moviespress);
function moviespress(e) {
    e.preventDefault();

    var count = 1;
    for (var i = 0; i < movies.length; i += 4) {
        // console.log(movies[i]);
        let moviename = document.createElement("h1");
        let description = document.createElement("h4");
        let movies_dir = document.createElement("h4");
        let rating = document.createElement("h4");
        let line = document.createElement("hr");
        line.style.borderTop = "2px solid black";
        moviename.innerText = (count) + ". " + movies[i];
        count++;
        description.innerText = movies[i + 1];
        movies_dir.innerText = movies[i + 2];
        rating.innerText = movies[i + 3];
        display_container.appendChild(moviename);
        display_container.appendChild(description);
        display_container.appendChild(movies_dir);
        display_container.appendChild(rating);
        display_container.appendChild(line);
    }


}


